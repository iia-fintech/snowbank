# snowbank
A python package to easily manage and integrate snowbank apis 

# Installation  

``` pip install snowbank ```
